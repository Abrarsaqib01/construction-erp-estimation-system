
# Construction ERP Estimation System

A full-stack ERP estimation module.

Features:
- Create estimates
- Department based quotations
- Margin and VAT calculation
- REST API backend
- Simple frontend dashboard

Tech Stack:
Backend: Node.js + Express
Frontend: HTML / JavaScript
Database: MySQL

Run Backend:
cd backend
npm install
node server.js

Open Frontend:
Open frontend/index.html in browser

Author:
Abrar Saqib
