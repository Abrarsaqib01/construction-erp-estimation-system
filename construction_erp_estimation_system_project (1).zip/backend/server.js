
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const estimateRoutes = require('./routes/estimateRoutes');

const app = express();

app.use(cors());
app.use(bodyParser.json());

app.use('/api/estimates', estimateRoutes);

const PORT = 5000;

app.listen(PORT, () => {
  console.log(`ERP Backend running on port ${PORT}`);
});
