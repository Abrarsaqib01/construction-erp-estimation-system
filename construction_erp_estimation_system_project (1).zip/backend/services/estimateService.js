
const mysql = require('mysql2/promise');

const dbConfig = {
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'erp_estimation'
};

exports.getEstimates = async () => {
  const conn = await mysql.createConnection(dbConfig);
  const [rows] = await conn.execute('SELECT * FROM estimates');
  return rows;
};

exports.createEstimate = async (estimate) => {
  const conn = await mysql.createConnection(dbConfig);
  const query = 'INSERT INTO estimates (department, margin, vat) VALUES (?, ?, ?)';
  const [result] = await conn.execute(query, [estimate.department, estimate.margin, estimate.vat]);
  return { id: result.insertId };
};
