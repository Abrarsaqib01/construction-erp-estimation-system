
CREATE DATABASE erp_estimation;

USE erp_estimation;

CREATE TABLE estimates (
 id INT AUTO_INCREMENT PRIMARY KEY,
 department VARCHAR(100),
 margin DECIMAL(10,2),
 vat DECIMAL(10,2)
);
