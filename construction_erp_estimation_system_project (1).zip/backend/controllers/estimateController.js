
const estimateService = require('../services/estimateService');

exports.getEstimates = async (req, res) => {
  const data = await estimateService.getEstimates();
  res.json(data);
};

exports.createEstimate = async (req, res) => {
  const result = await estimateService.createEstimate(req.body);
  res.json(result);
};
